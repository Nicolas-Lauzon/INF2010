package tp1;

public class Circle extends Ellipse {
    public Circle(Double radius) {
        super(radius, radius);
    }
}
